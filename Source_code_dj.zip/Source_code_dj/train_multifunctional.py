# -*- coding: utf-8 -*-
from __future__ import print_function
from keras.models import Model
from keras.layers import Dense, Dropout, Input, LSTM
from keras.layers import Bidirectional, Masking, Embedding, concatenate
from keras.layers import BatchNormalization, Activation, TimeDistributed
from keras.layers import Conv1D, GlobalMaxPooling1D, Lambda
from keras.optimizers import Adam
from keras import backend
from attention_model import AttentionLayer
from sklearn.utils import shuffle
import numpy as np
from data_preprocessing import data
from keras.callbacks import TensorBoard
import os
import scipy.io as scio
from sklearn.metrics import confusion_matrix
import random
import pyexcel as pe


## TRAING PARAMS
batch_size = 8
epoch_count = 300
acc_flag_threshould = 60 # threshould of flag to detect in-training effects, not must
acc_collection = [] # all accuracies
work_path = '/Users/jiachending/Documents/Phase_pred_GCS'
saving_path = '/Users/jiachending/Documents/CNMC'
saving_name = ['result/train_text.mat', 'result/test_text.mat']
#label_mode = 'lower_10'
label_mode = 'phase'

## LOAD DATA
cirno = data(path = work_path) # all train/test data
cirno.auto_process(merge_unclear = True, load_audio = False)
cirno.label_mode = label_mode
if label_mode == 'lower_10':
    numclass = 11
elif label_mode == 'h':
    numclass = len(cirno.label_dic_h)
elif label_mode == 'm':
    numclass = len(cirno.label_dic_m)
elif label_mode == 'l':
    numclass = len(cirno.label_dic_l)
# for phase prediction
elif label_mode == 'phase':
    numclass = 3
else:
    numclass = len(cirno.trainer_lbl_statistics) - len(cirno.unclear_lbl) + 4
    print('>!>Warning, unknown label mode')

numclass = 3 # for GCS phase mode

## IN-TRAINING FUNCTIONS
def output_result(train_text, test_text):
    train_text_save_name = saving_path + saving_name[0]
    if os.path.exists(train_text_save_name): os.remove(train_text_save_name)
    scio.savemat(train_text_save_name)

    test_text_save_name = saving_path + saving_name[1]
    if os.path.exists(test_text_save_name): os.remove(test_text_save_name)
    scio.savemat(test_text_save_name)

def weight_expand(x):
    return backend.expand_dims(x)

def weight_dot(inputs):
    return inputs[0] * inputs[1]

def to_one_digit_label(onehot_labels):
    res = []
    for label in onehot_labels: res.append(np.argmax(label))
    return res

# callback for tensorboard
tb_callback = TensorBoard(log_dir = work_path + '/analyze/tensorboard',
                                         histogram_freq = 1,
                                         write_graph = True,
                                         write_images = True)

## TEXT MODEL
# input and its shape
text_input = Input(shape = (30,), name = 'ph1_input')
# word embedding
em_text = Embedding(len(cirno.word_dic) + 1,
                    200,
                    weights = [cirno.get_embed_matrix()],
                    trainable = True)(text_input)
# masking layer
text = Masking(mask_value = 0.,
               name = 'ph1_mask')(em_text)
# LSTM layer
text = LSTM(512,
            return_sequences = True,
            recurrent_dropout = 0.25,
            name = 'ph1_LSTM_text_1')(text)
text = LSTM(256,
            return_sequences = True,
            recurrent_dropout = 0.25,
            name = 'ph1_LSTM_text_2')(text)

# batch normalization
#text_l1 = BatchNormalization(name=)(text_l1)
# attention layer
text_weight = AttentionLayer(name = 'ph1_att')(text)
text_weight = Lambda(weight_expand, name = 'ph1_lam1')(text_weight) # Get the score
text_vector = Lambda(weight_dot, name = 'ph1_lam2')([text, text_weight])
text_feature_vector = Lambda(lambda x: backend.sum(x, axis = 1), name = 'ph1_lam3')(text_vector)
text_weight_inter = Model(inputs = text_input, output = text_weight) # output mid-layer res
# dropout layer
dropout_text = Dropout(0.25, name = 'ph1_drop1')(text_feature_vector)
dense_text_1 = Dense(128, activation = 'relu', name = 'ph1_dense')(dropout_text)
dropout_text = Dropout(0.25, name = 'ph1_drop2')(dense_text_1)
# decision-making
text_prediction = Dense(numclass, activation = 'softmax', name = 'ph1_dec')(dropout_text)
text_model = Model(inputs = text_input, outputs = text_prediction, name = 'ph1_model')
#inter_text = Model(inputs = text_input, outputs = text_feature_vector)
# optimizer
adam = Adam(lr = 0.0001, beta_1 = 0.9, beta_2 = 0.999, epsilon = 1e-08)
text_model.compile(loss = 'categorical_crossentropy', optimizer = adam, metrics = ['accuracy'])
text_model.summary()

## MAIN


def generate_confusion_matrix():
    # Calc confusion matrix
    test_label, test_text, _1, _2 = cirno.get_tester(debug=True)
    predictions = text_model.predict(test_text)
    confusion = confusion_matrix(np.argmax(test_label, axis=1), np.argmax(predictions, axis=1))
    print(confusion)
    np.savetxt(work_path + "analyze/confusion_matrix.csv", confusion, fmt='%.0f', delimiter=",")

    index_to_label = {}
    for label, raw_index in cirno.tester_lbl_dic.items():
        index = cirno.lower_10_transfer_dic[raw_index]
        if index_to_label.get(index) != 'NULL':
            index_to_label[index] = label
    print(index_to_label)

def analyze_gcs_label():
    import json
    def str_makeup(st, length):
        st = str(st)
        st += " " * length
        return st[:length]
    text_model.load_weights(saving_path + 'text_on_loss_output_weights.h5')
    lbl, txt, _l, _r, raw_lbl, raw_txt = cirno.get_data_for_analyze(label="GCS Calculation")
    #text_model.fit(txt, lbl, batch_size=batch_size, epochs=1, verbose=1)
    mock_model = Model(input=text_model.input, output=text_model.get_layer('ph1_lam1').output)
    # mock_model_output = mock_model.predict(txt[0][np.newaxis, :])

    f = open(saving_path + 'hospital_data/analyze/gcs_analyze.txt', 'w')
    results = {}
    for i in range(len(raw_lbl)):
        results[str(i)] = []
        results[str(i)].append({
            'label': raw_lbl[i],
            'sentence': str(raw_txt[i]),
            'result': str(mock_model.predict(txt[i][np.newaxis, :]))
        })
        f.write(str_makeup(i, 5) + str(raw_txt[i]))
        f.write('\n' + str(mock_model.predict(txt[i][np.newaxis, :])))
        f.write('\n\n')
    f.close()

    with open(saving_path + 'hospital_data/analyze/gcs_analyze.json', 'w') as json_out:
        json.dump(results, json_out)


def train_gcs_phase():
    from keras.preprocessing import sequence
    from keras.utils.np_utils import to_categorical
    import random
    from datetime import datetime
    from sklearn.metrics import confusion_matrix

    acc_max = 0
    loss_min = 1.0
    epoch_count = 300

    '''get raw data'''
    _, _, _, _, train_raw_lbl, train_raw_txt = cirno.get_data_for_analyze(traintest="train")
    _, _, _, _, test_raw_lbl, test_raw_txt = cirno.get_data_for_analyze(traintest="test")

    '''change label tag'''
    for i in range(len(train_raw_lbl)):
        if train_raw_lbl[i] == "before":
            train_raw_lbl[i] = 1
        elif train_raw_lbl[i] == 'during':
            train_raw_lbl[i] = 2
        else:
            train_raw_lbl[i] = 0


    for i in range(len(test_raw_lbl)):
        if test_raw_lbl[i] == "before":
            test_raw_lbl[i] = 1
        elif test_raw_lbl[i] == "during":
            test_raw_lbl[i] = 2
        else:
            test_raw_lbl[i] = 0
    # text_model.load_weights(saving_path + 'entire_text_output_weights.h5')

    for i in range(1, epoch_count + 1):
        print('\n\n>>>High-level-label Text Training Epoch: ' + str(i) + ' out of ' + str(epoch_count))

        '''average'''
        train_lbl, train_txt= [], []
        train_size = 40

        random.seed(datetime.now())
        train_size = min(train_size, len(train_raw_lbl)) # prevent inf loop
        train_indexes = set([])
        while(len(train_indexes) < (train_size / 2)): # randomly generate index
            random_index = random.randint(0, len(train_raw_lbl) - 1)
            if (train_raw_lbl[random_index] == 0):
                train_indexes.add(random_index)
        while (len(train_indexes) < train_size):  # randomly generate index
            random_index = random.randint(0, len(train_raw_lbl) - 1)
            if (train_raw_lbl[random_index] == 1):
                train_indexes.add(random_index)
        for index in train_indexes:
            train_lbl.append(train_raw_lbl[index])
            train_txt.append(train_raw_txt[index])

        test_lbl, test_txt= [], []
        test_size = 20

        test_size = min(test_size, len(test_raw_lbl)) # prevent inf loop
        test_indexes = set([])
        while(len(test_indexes) < (test_size / 2)): # randomly generate index
            random_index = random.randint(0, len(test_raw_lbl) - 1)
            if (test_raw_lbl[random_index] == 0):
                test_indexes.add(random_index)
        while (len(test_indexes) < test_size):  # randomly generate index
            random_index = random.randint(0, len(test_raw_lbl) - 1)
            if (test_raw_lbl[random_index] == 1):
                test_indexes.add(random_index)

        for index in test_indexes:
            test_lbl.append(train_raw_lbl[index])
            test_txt.append(train_raw_txt[index])

        '''manual preprocesses'''
        sent_pad_len = 30

        train_label = to_categorical(train_lbl, num_classes=3)
        test_label = to_categorical(test_lbl, num_classes=3)
        train_text = sequence.pad_sequences(train_txt, dtype='float32', maxlen=sent_pad_len, padding='pre')
        test_text = sequence.pad_sequences(test_txt, dtype='float32', maxlen=sent_pad_len, padding='pre')


        '''train'''
        text_model.fit(train_text,
                       train_label,
                       batch_size=batch_size,
                       epochs=1,
                       verbose=1)
        '''evaluate'''
        loss, acc = text_model.evaluate(test_text,
                                        test_label,
                                        batch_size=batch_size,
                                        verbose=0)
        acc_collection.append(acc)
        print('>Accuaracy = {:.2f} | Loss = {:.2f}'.format(acc, loss))
        # weights = text_model.get_weights()
        cirno.write_epoch_acc(i, acc)  # record in analyze file
        if acc > acc_max:
            acc_max = acc
        if loss < loss_min:
            loss_min = loss
            text_model.save_weights(saving_path + 'gcs_phase_output_weights.h5')

    print('\n\n>>>High-level-label Training All Done')
    print('>Max Text Acc = ', acc_max)
    print('>Min Text Los = ', loss_min)

    '''confusion matrix'''
    text_model.load_weights(saving_path + 'gcs_phase_output_weights.h5')
    test_label = to_categorical(test_raw_lbl, num_classes=3)
    test_text = sequence.pad_sequences(test_raw_txt, dtype='float32', maxlen=sent_pad_len, padding='pre')
    predictions = text_model.predict(test_text)
    confusion = confusion_matrix(np.argmax(test_label, axis=1), np.argmax(predictions, axis=1))
    print(confusion)


def train_gcs_vs_others():
    from keras.preprocessing import sequence
    from keras.utils.np_utils import to_categorical
    import random
    from datetime import datetime
    from sklearn.metrics import confusion_matrix

    acc_max = 0
    loss_min = 1.0
    epoch_count = 100

    '''get raw data'''
    _, _, _, _, train_raw_lbl, train_raw_txt = cirno.get_data_for_analyze(traintest="train")
    _, _, _, _, test_raw_lbl, test_raw_txt = cirno.get_data_for_analyze(traintest="test")

    '''change label tag'''
    for i in range(len(train_raw_lbl)):
        train_raw_lbl[i] = 1 if train_raw_lbl[i] == "GCS Calculation" else 0
    for i in range(len(test_raw_lbl)):
        test_raw_lbl[i] = 1 if test_raw_lbl[i] == "GCS Calculation" else 0

    # text_model.load_weights(saving_path + 'entire_text_output_weights.h5')
    for i in range(1, epoch_count + 1):
        print('\n\n>>>High-level-label Text Training Epoch: ' + str(i) + ' out of ' + str(epoch_count))

        '''average'''
        train_lbl, train_txt= [], []
        train_size = 60

        random.seed(datetime.now())
        train_size = min(train_size, len(train_raw_lbl)) # prevent inf loop
        train_indexes = set([])
        while(len(train_indexes) < (train_size / 2)): # randomly generate index
            random_index = random.randint(0, len(train_raw_lbl) - 1)
            if (train_raw_lbl[random_index] == 0):
                train_indexes.add(random_index)
        while (len(train_indexes) < train_size):  # randomly generate index
            random_index = random.randint(0, len(train_raw_lbl) - 1)
            if (train_raw_lbl[random_index] == 1):
                train_indexes.add(random_index)
        for index in train_indexes:
            train_lbl.append(train_raw_lbl[index])
            train_txt.append(train_raw_txt[index])

        test_lbl, test_txt= [], []
        test_size = 60

        test_size = min(test_size, len(test_raw_lbl)) # prevent inf loop
        test_indexes = set([])
        while(len(test_indexes) < (test_size / 2)): # randomly generate index
            random_index = random.randint(0, len(test_raw_lbl) - 1)
            if (test_raw_lbl[random_index] == 0):
                test_indexes.add(random_index)
        while (len(test_indexes) < test_size):  # randomly generate index
            random_index = random.randint(0, len(test_raw_lbl) - 1)
            if (test_raw_lbl[random_index] == 1):
                test_indexes.add(random_index)
        for index in test_indexes:
            test_lbl.append(train_raw_lbl[index])
            test_txt.append(train_raw_txt[index])

        '''manual preprocesses'''
        sent_pad_len = 30

        train_label = to_categorical(train_lbl, num_classes=2)
        test_label = to_categorical(test_lbl, num_classes=2)
        train_text = sequence.pad_sequences(train_txt, dtype='float32', maxlen=sent_pad_len, padding='pre')
        test_text = sequence.pad_sequences(test_txt, dtype='float32', maxlen=sent_pad_len, padding='pre')


        '''train'''
        text_model.fit(train_text,
                       train_label,
                       batch_size=batch_size,
                       epochs=1,
                       verbose=1)
        '''evaluate'''
        loss, acc = text_model.evaluate(test_text,
                                        test_label,
                                        batch_size=batch_size,
                                        verbose=0)
        acc_collection.append(acc)
        print('>Accuaracy = {:.2f} | Loss = {:.2f}'.format(acc, loss))
        # weights = text_model.get_weights()
        cirno.write_epoch_acc(i, acc)  # record in analyze file
        if acc > acc_max:
            acc_max = acc
        if loss < loss_min:
            loss_min = loss
            text_model.save_weights(saving_path + 'gcs_vs_others_output_weights.h5')

    print('\n\n>>>High-level-label Training All Done')
    print('>Max Text Acc = ', acc_max)
    print('>Min Text Los = ', loss_min)

    '''confusion matrix'''
    text_model.load_weights(saving_path + 'gcs_vs_others_output_weights.h5')
    test_label = to_categorical(test_raw_lbl, num_classes=2)
    test_text = sequence.pad_sequences(test_raw_txt, dtype='float32', maxlen=sent_pad_len, padding='pre')
    predictions = text_model.predict(test_text)
    confusion = confusion_matrix(np.argmax(test_label, axis=1), np.argmax(predictions, axis=1))
    print(confusion)
    #np.savetxt(work_path + "/analyze/confusion_matrix.csv", confusion, fmt='%.0f', delimiter=",")


if __name__ == "__main__":
    train_gcs_phase()
