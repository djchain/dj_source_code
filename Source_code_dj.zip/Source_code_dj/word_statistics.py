# -*- coding: utf-8 -*-
"""
Created on MAR 01 2019
This scipt helps do statistics upon current dataset
@author: Jiachen Ding
@version: 20190301 20190313
"""
from data_preprocessing import data
import csv





def countGCS():
    '''This function helps count words in sentences labeled "GCS"'''
    datamap = cirno.data
    statistics = {}

    def includesGCS(l):
        # find if list of labels includes GCS
        for label in l:
            if label.lower().find('gcs') >= 0:
                # print(label)
                return True
        return False

    for v in datamap.values():
        if includesGCS(v[3]):
            for word in v[0]:
                statistics[word.lower()] = statistics.get(word.lower(), 0) + 1

    with open("D:/CNMC/hospital_data/analyze/GCS_statistics.csv", "w", newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["word", "count"])
        for k, v in sorted(statistics.items(), key=lambda item: item[1], reverse=True):
            writer.writerow([k, str(v)])

    print('>>>Compeleted statistics for GCS')

def filterTargetLabelsAndSaveAllData(labels):
    '''This function filters label from data set and saves correlated audio and sentences'''
    datamap = cirno.data
    with open("D:/CNMC/hospital_data/analyze/4_label_statistics.csv", "w", newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["file", "label", "sentence"])
        for key, val in sorted(datamap.items(), key=lambda item: item[0]):
            if val[3][0] in labels: # lower_10/low mode
                file = '/' + key[0][:6] + '/' + str(key[1]) + '.wav'
                label = val[3][0]
                sentence = " ".join(val[0])
                writer.writerow([file, label, sentence])
    print('>>>Compeleted statistics for target labels')


if __name__ == "__main__":
    cirno = data(path='D:/CNMC/hospital_data');
    cirno.auto_process(merge_unclear=True, load_audio=False)
    cirno.label_mode = 'lower_10'

    filterTargetLabelsAndSaveAllData(('GCS Calculation', 'Oxygen', 'Pulse Check', 'Blood Pressure'))
